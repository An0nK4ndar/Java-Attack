# NEXUS_STRINGS
A Most Java Powerful DDoS 

> DDos-Tool was created to destroy Indian Wedsite, this script is very powerful!

---
#### Features
- [x] Fast ddos
- [x] Free proxy
- [x] Supported on java
- [x] Supported other systems
- [x] Quickly and clearly
- [x] Functionality


----

### kali Installing (RDP/VPS)

* `sudo apt update`
* `sudo apt upgrade`
* `sudo apt install git`
* `sudo apt install default-jdk `

* `https://github.com/username/file.git`

### Installing (TERMUX/TERMINAL)

* `pkg update`
* `pkg upgrade`
* `pkg install git`
* `pkg install openjdk-17`
* `https://github.com/username/file`



#### Finished you have successfully downloaded DDos-Tool now to launch!

* `cd File`
* `java file.java`

-----
## Dependencies

```
Wifi   : True
Root   : No Root
Package: 610 kB
```
